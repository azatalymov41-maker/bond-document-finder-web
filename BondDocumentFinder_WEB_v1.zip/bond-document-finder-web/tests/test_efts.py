from bondfinder.sec import SECClient

def test_efts_hit_url(monkeypatch):
    api=object.__new__(SECClient)
    class Response:
        def json(self):
            return {'hits':{'hits':[{'_id':'0001234567-26-000012:ex4-1.htm',
                '_source':{'ciks':['1144879'],'adsh':'0001234567-26-000012',
                           'form':'8-K','display_names':['APLD ComputeCo'],
                           'file_date':'2026-03-10'}}]}}
    monkeypatch.setattr(api,'get',lambda *args,**kwargs:Response())
    result=api.search_efts('foo')[0]
    assert result['url']=='https://www.sec.gov/Archives/edgar/data/1144879/000123456726000012/ex4-1.htm'

def test_invalid_external_url():
    api=object.__new__(SECClient)
    import pytest
    from bondfinder.sec import SECError
    with pytest.raises(SECError):api.get('https://evil.example.com/test')
