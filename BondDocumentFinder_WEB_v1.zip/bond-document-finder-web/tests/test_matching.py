from bondfinder.matching import (Bond, inferred_identifiers, evidence_score,category,
                                 status_from_evidence,normalize_date,
                                 extract_bond_from_query,maturity_variants)
from bondfinder.sec import build_queries

def test_us_isin_to_cusip():
    assert inferred_identifiers(Bond(isin='US03772CAA18')).cusip=='03772CAA1'

def test_dates():
    assert normalize_date('15.03.2031')=='2031-03-15'
    assert normalize_date('1may2032')=='2032-05-01'
    assert 'March 15, 2031' in maturity_variants('2031-03-15')

def test_structured_query():
    b=extract_bond_from_query('Prologis Euro Finance 4% 05.05.2034 EUR')
    assert b.issuer=='Prologis Euro Finance'
    assert b.coupon=='4'
    assert b.maturity=='2034-05-05'
    assert b.currency=='EUR'

def test_isin_from_query():
    b=extract_bond_from_query('US03772CAA18 APLD ComputeCo 2, 6.75% 15mar2031 USD')
    assert b.isin=='US03772CAA18'
    assert b.issuer=='APLD ComputeCo 2'
    assert b.maturity=='2031-03-15'

def test_primary_evidence_without_isin():
    b=Bond(isin='US03772CAA18',issuer='APLD ComputeCo 2 LLC',coupon='6.75',maturity='2031-03-15')
    text='Indenture relating to APLD ComputeCo 2 LLC 6.75% notes due March 15, 2031'
    score,ev=evidence_score(b,text,form='EX-4.1')
    assert score>=40
    assert status_from_evidence(ev,category('Indenture EX-4.1','EX-4.1',text))=='Primary document candidate — review'

def test_holdings_not_primary():
    b=Bond(isin='US03772CAA18')
    _,ev=evidence_score(b,'US03772CAA18',form='NPORT-P')
    assert status_from_evidence(ev,category('US03772CAA18','NPORT-P'))!='Primary document candidate — review'

def test_8k_mention_is_not_indenture():
    assert category('APLD FORM 8-K','8-K','An indenture was executed')=='Other SEC filing'

def test_queries():
    b=Bond(isin='US03772CAA18',issuer='APLD ComputeCo 2 LLC',coupon='6.75',maturity='2031-03-15')
    q=build_queries(b)
    assert '"US03772CAA18"' in q
    assert '"03772CAA1"' in q
